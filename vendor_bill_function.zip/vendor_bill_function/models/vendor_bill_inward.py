from odoo import fields, models, api
from odoo.exceptions import UserError

class AccountMove(models.Model):
    _inherit = "account.move"

    receipt_count = fields.Integer(string='Receipt Orders', compute='_compute_receipts')

    def action_create_receipt(self):
        # Stock in type for vendor bills (incoming shipments)
        picking_type = self.env.ref('stock.picking_type_in')
        if not picking_type:
            raise UserError('Picking type not found')

        # Creating the stock picking for incoming products
        picking = self.env["stock.picking"].create({
            "partner_id": self.partner_id.id,
            "scheduled_date": self.invoice_date,
            "date_deadline": self.invoice_date_due,
            "origin": self.name,
            "move_type": "direct",
            "picking_type_id": picking_type.id,
            "location_id": self.partner_id.property_stock_supplier.id,  # Vendor location
            "location_dest_id": self.env.ref('stock.stock_location_stock').id,  # Stock location
        })

        # Creating stock moves based on invoice lines
        StockMove = self.env["stock.move"]
        for line in self.invoice_line_ids:
            StockMove.create({
                "name": line.name,
                "date": line.date,
                "product_uom": line.product_id.uom_id.id,
                "picking_id": picking.id,
                "product_id": line.product_id.id,
                "location_id": self.partner_id.property_stock_supplier.id,  # Vendor location
                "location_dest_id": self.env.ref('stock.stock_location_stock').id,  # Stock location
            })

        return picking

    @api.depends('invoice_line_ids')
    def _compute_receipts(self):
        for order in self:
            # Counting receipts related to this vendor bill
            receipts = self.env['stock.picking'].search([('origin', '=', order.name)])
            order.receipt_count = len(receipts)

    def action_view_receipt(self):
        return {
            "name": "Receipt",
            "type": "ir.actions.act_window",
            "res_model": "stock.picking",
            "view_mode": "tree,form",
            "domain": [('origin', '=', self.name)],
        }
